package com;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.dao.StudentRepository;

@SpringBootTest
public class MyMockitoTest {
	
	StudentRepository studRepo = Mockito.mock(StudentRepository.class);
	
	@Test
	void testSname() {
		Mockito.when(studRepo.getStudentNameById(1022)).thenReturn("Bhushan");
		Assertions.assertEquals("Bhushan", studRepo.getStudentNameById(1022));
		
	}
	
	@Test
	void testNameBySage() {
		Mockito.when(studRepo.getStudentNameWhoseAgeIs(19)).thenReturn("Kevin");
		Assertions.assertEquals("Kevin", studRepo.getStudentNameWhoseAgeIs(19));
	}

}
