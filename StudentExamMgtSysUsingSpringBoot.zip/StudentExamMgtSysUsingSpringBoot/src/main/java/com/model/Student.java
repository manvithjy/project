package com.model;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



@Entity
@Table(name = "Student")
public class Student {
	
	//Declaring private variables
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int studRollNo;
	private String studFirstName;
	private String studLastName;
	private String studGender;
	private String studPassword;
	private String studAddress;
	private String studEmail;
	private String studCourse;
	
	//creating constructors using without fields
	public Student() {
		super();
	}

	//creating constructors using with fields
	public Student(int studRollNo, String studFirstName, String studLastName, String studGender, String studPassword,
			String studAddress, String studEmail, String studCourse) {
		super();
		this.studRollNo = studRollNo;
		this.studFirstName = studFirstName;
		this.studLastName = studLastName;
		this.studGender = studGender;
		this.studPassword = studPassword;
		this.studAddress = studAddress;
		this.studEmail = studEmail;
		this.studCourse = studCourse;
	}

	//creating getters and setters for all private variable declaration to access the data
	public int getStudRollNo() {
		return studRollNo;
	}

	public void setStudRollNo(int studRollNo) {
		this.studRollNo = studRollNo;
	}

	public String getStudFirstName() {
		return studFirstName;
	}

	public void setStudFirstName(String studFirstName) {
		this.studFirstName = studFirstName;
	}

	public String getStudLastName() {
		return studLastName;
	}

	public void setStudLastName(String studLastName) {
		this.studLastName = studLastName;
	}

	public String getStudGender() {
		return studGender;
	}

	public void setStudGender(String studGender) {
		this.studGender = studGender;
	}

	public String getStudPassword() {
		return studPassword;
	}

	public void setStudPassword(String studPassword) {
		this.studPassword = studPassword;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}

	public String getStudEmail() {
		return studEmail;
	}

	public void setStudEmail(String studEmail) {
		this.studEmail = studEmail;
	}

	public String getStudCourse() {
		return studCourse;
	}

	public void setStudCourse(String studCourse) {
		this.studCourse = studCourse;
	}

	@Override
	public String toString() {
		return "\nStudent [studRollNo=" + studRollNo + ", studFirstName=" + studFirstName + ", studLastName="
				+ studLastName + ", studGender=" + studGender + ", studPassword=" + studPassword + ", studAddress="
				+ studAddress + ", studEmail=" + studEmail + ", studCourse=" + studCourse + "]";
	}

	
}
