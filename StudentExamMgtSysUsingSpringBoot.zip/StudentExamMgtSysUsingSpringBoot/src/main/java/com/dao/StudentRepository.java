package com.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {

	

	Optional<Student> findBystudFirstName(String studFirstName);

}
