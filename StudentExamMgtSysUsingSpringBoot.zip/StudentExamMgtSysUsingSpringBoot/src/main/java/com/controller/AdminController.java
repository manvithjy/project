package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.QuestionRepository;
import com.dao.StudentRepository;
import com.model.Question;
import com.model.Student;

@Controller
@RequestMapping("/exam")

public class AdminController {

	@Autowired
	StudentRepository studrepo;
	
	@Autowired
	QuestionRepository querepo;
	
	
	
	@RequestMapping("/home")
	public String home() {
		return "home";

	}
	
	//@PreAuthorize("hasRole('Admin')")
	@RequestMapping("admin")
	public String getadmin() {
		return "admin";

	}
	
	
	//-------------------Admin operations---------------------
	
	//---------Student related operations------------
	@RequestMapping("/addstudent")
	public String addStudent() {
		return "addstudent";

	}
	
	@RequestMapping("/added")
	public String addStudentInDb(@ModelAttribute Student student, Model model) {
		Student stud = new Student();
		stud.setStudFirstName(student.getStudFirstName());
		stud.setStudLastName(student.getStudLastName());
		stud.setStudGender(student.getStudGender());
		stud.setStudPassword(student.getStudPassword());
		stud.setStudAddress(student.getStudAddress());
		stud.setStudEmail(student.getStudEmail());
		stud.setStudCourse(student.getStudCourse());
		studrepo.save(stud);
		System.out.println("Added ");
		model.addAttribute("student", student);
		return "addedsuccess";

	}
	
	//update
	@RequestMapping("/updatestudent")
	public String updateStudent() {
		return "updatestudent";

	}
	
	@RequestMapping("/updateInDB")
	public String updateInDb(@ModelAttribute Student student) {
		Student std = new Student();
		Optional<Student> stud = studrepo.findById(student.getStudRollNo());
		std = stud.get();
		std.setStudFirstName(student.getStudFirstName());
		std.setStudLastName(student.getStudLastName());
		std.setStudGender(student.getStudGender());
		std.setStudPassword(student.getStudPassword());
		std.setStudAddress(student.getStudAddress());
		std.setStudEmail(student.getStudEmail());
		std.setStudCourse(student.getStudCourse());
		studrepo.save(std);
		return "updatesuccess";

	}
	
	
	//delete student by ID
	@RequestMapping("/deletestudent")
	public String deleteStudent() {
		return "deletestudent";

	}

	@RequestMapping("deletefromdb")
	public String deleteFromDatabase(@RequestParam("studRollNo") int studRollNo) {
		studrepo.deleteById(studRollNo);
		
		return "deletesuccess";

	}
	
	//get all students
	@RequestMapping("/getstudents")
	public String getAllStudents(Model model) {
		List<Student> list = (List<Student>) studrepo.findAll();
		model.addAttribute("students", list);
		return "getallstudents";

	}
	
	//get Students By ID
	@RequestMapping("/getstudent")
	public String getStudent() {
		return "getstudent";

	}
	
	@RequestMapping("displaystudent")
	public String displayStudent(@RequestParam("studRollNo") int studRollNo, Model model) {
		Student st = studrepo.findById(studRollNo).get();
		model.addAttribute("student",st);
		return "displaystudent";
		
		
	}
	
	//find by name
	//get Students By ID
		@RequestMapping("/getstudentbyname")
		public String getStudentByName() {
			return "getstudentbyname";

		}
		
		@RequestMapping("studentbyname")
		public String displayStudentByName(@RequestParam("StudFirstName") String StudFirstName, Model model) {
			Student st = studrepo.findBystudFirstName(StudFirstName).get();
			model.addAttribute("student",st);
			return "displaystudentbyName";
			
			
		}
		
		
		
	
	
	
	
	
	//------------------Question operations------------------
	
	//addQuestion
	@RequestMapping("/addquestion")
	public String addQuestion() {
		return "addquestion";

	}
	
	@RequestMapping("/adque")
	public String addQuestioninDB(@ModelAttribute Question question, Model model) {
		Question que = new Question();
		que.setQueid(question.getQueid());
		que.setQuestion(question.getQuestion());
		que.setOpt1(question.getOpt1());
		que.setOpt2(question.getOpt2());
		que.setOpt3(question.getOpt3());
		que.setOpt4(question.getOpt4());
		que.setCorrectAns(question.getCorrectAns());
		querepo.save(que);
		System.out.println("queAdded");
		model.addAttribute("question", question);
		return "quesuccess";

	}
	//hit al ahe
	//update question
	@RequestMapping("/updatequestion")
	public String updateQuestion() {
		return "updatequestion";
	}
	
	@RequestMapping("/updateque")
	public String updateQuestionInDb(@ModelAttribute Question question) {
		Question que = new Question();
		Optional<Question> ques = querepo.findById(question.getExamId());
		que = ques.get();
		que.setQueid(question.getQueid());
		que.setQuestion(question.getQuestion());
		que.setOpt1(question.getOpt1());
		que.setOpt2(question.getOpt2());
		que.setOpt3(question.getOpt3());
		que.setOpt4(question.getOpt4());
		
		que.setCorrectAns(question.getCorrectAns());
		querepo.save(que);
		return "queupdatesuccess";
           
	}
	
	// getQuetions 
	@RequestMapping("/getquestions")
	public String getAllQuestions(Model model) {
		List<Question> list = (List<Question>) querepo.findAll();
		model.addAttribute("questions", list);
		return "getallquestions";

	}
	
	//delete Question by examId by ID
		@RequestMapping("/deletequestion")
		public String deleteQuestion() {
			return "deletequestion";

		}

		@RequestMapping("deleteques")
		public String deleteQues(@RequestParam("Queid") int Queid) {
			studrepo.deleteById(Queid);
			return "deletequesuccess";

		}
	
	
	
}
