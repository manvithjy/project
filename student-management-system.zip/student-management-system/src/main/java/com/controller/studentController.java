package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dao.StudentDaoImpl;
import com.entity.Student;
import com.service.StudentServiceImpl;


@Controller

public class studentController {
	
	
	@Autowired
	private StudentServiceImpl studentServiceImpl;
	
	/////////////read ://////////////////////////////////
	
	@RequestMapping("/showStudentLists")
	public String showStudentList(Model model) {
		
	List<Student> studentList = studentServiceImpl.getAllStudents();
	
	for(Student tempStudent:studentList ) 
	{
		System.out.println(tempStudent.toString());
	}
	model.addAttribute("stdList",studentList);

	return "student-list";
	}
	
	//////////////////// add student////////////////////////////
	
	@RequestMapping("/addStudent")
	public String addStudent(Model model) {
		Student stdDao = new  Student();
		
		model.addAttribute("student",stdDao);
		
		return "add-student";
	}
	
	////////////////student added /////////////////////////////
	
	
	@RequestMapping("/studentadded")
	public String  StudentAdded(Student student) {
		
		System.out.println(student);
		
		if(student.getId()==0) {
			studentServiceImpl.saveStudent(student);		
		}
		else {
			studentServiceImpl.updateStudent(student);
		}
		return "redirect:/showStudentLists";
	}
	
	//////////////// update data ///////////////////////////
	
	@RequestMapping("/updateStudent")
	public String updateStudent(@RequestParam("userId") int id,Model model ) {
		System.out.println("looking for the data for the student having id:"+id);
		
		Student thestd = studentServiceImpl.getStudent(id);
		System.out.println(thestd);
		
		
		model.addAttribute("student",thestd);
		return "add-student";
	}
	
	///////////////// delete data ///////////////
	
	
	@RequestMapping("/deleteStudent")
	public String deleteStudent(@RequestParam("userId") int id) {
		studentServiceImpl.deleteStudent(id);
		
		return "redirect:/showStudentLists";
	}
	

	}
	
	

