package com.service;

import java.util.List;

import com.entity.Student;

public interface StudentService {
	
	public List<Student> getAllStudents();
	
	void saveStudent(Student student);
	
	Student getStudent(int id);
	
	void updateStudent(Student student);
	
	public void deleteStudent(int id) ;
	
	

}
