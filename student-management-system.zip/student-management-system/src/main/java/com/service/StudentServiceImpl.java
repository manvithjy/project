package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.StudentDaoImpl;
import com.entity.Student;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDaoImpl studentDaoImpl;
	
	public List<Student> getAllStudents() {
		
		List<Student> StudentsList = studentDaoImpl.getAllStudents();
		
		return StudentsList;
	}

	public void saveStudent(Student student) {
		
		if(student.getCountry().equals("uk")) {
			System.out.println("email sent to:"+student.getName());
		}
		studentDaoImpl.saveStudent(student);
		
	}

	public Student getStudent(int id) {
		Student student = studentDaoImpl.getStudent(id);
		return student;
	}

	public void updateStudent(Student student) {
		studentDaoImpl.updateStudent(student);
		
	}

	public void deleteStudent(int id) {
		studentDaoImpl.deleteStudent(id);
		
	}

	
	
	

}
