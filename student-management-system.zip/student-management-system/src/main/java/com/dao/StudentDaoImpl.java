package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.entity.Student;
import com.rowMapper.studentRowMapper;


@Repository
public class StudentDaoImpl implements StudentDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<Student> getAllStudents() {
		
		List<Student> StdList = new ArrayList<Student>();
		
		String sql = "SELECT * FROM students";
		List<Student> listOfStudent = jdbcTemplate.query(sql, new studentRowMapper());
		
		return listOfStudent;
				
	}

	public void saveStudent(Student student) {
		
		Object[] sqlparameters = {student.getName(),student.getMobileNo(),student.getCountry()};
		String sql = "insert into students(name,mobileNo,country) values(?,?,?)";
		jdbcTemplate.update(sql,sqlparameters);
		System.out.println("1 record inserted..");
	}

	public Student getStudent(int id) {
		
		String sql ="SELECT * FROM students where id=?";
		Student std = jdbcTemplate.queryForObject(sql, new studentRowMapper(),id);
		return std;
	}

	public void updateStudent(Student student) {
		String sql = "update students set name=?,mobileNo=?,country=? where id =?";
		jdbcTemplate.update(sql,student.getName(),student.getMobileNo(),student.getCountry(),student.getId());
		System.out.println("1 recored upadted...");
		
	}

	public void deleteStudent(int id) {
		String sql="delete from students where id=?";
		jdbcTemplate.update(sql,id);
	}

	
	

}
 