package com.dao;

import java.util.List;

import com.entity.Student;

public interface StudentDao {
	
	List<Student> getAllStudents();
	
	void saveStudent(Student student);
	
	Student getStudent(int id);
	
	void updateStudent(Student student);
	
	public void deleteStudent(int id);

}
