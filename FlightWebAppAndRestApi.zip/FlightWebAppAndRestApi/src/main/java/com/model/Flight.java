package com.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "Flight")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fid;
	@NotNull(message = "Name can't be null")
	private String fname;
	@NotBlank(message = "Can't be blank")
	private String forigin;
	@NotBlank(message = "Can't be blank")
	private String fdestination;
	@NotBlank(message = "Can't be blank")
	private String darrival;
	@NotNull(message = "Can't be blank")
	private int ddepart;
	@Min(1)
	private int fpriceeco;
	@Min(1)
	private int fpricebus;

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getForigin() {
		return forigin;
	}

	public void setForigin(String forigin) {
		this.forigin = forigin;
	}

	public String getFdestination() {
		return fdestination;
	}

	public void setFdestination(String fdestination) {
		this.fdestination = fdestination;
	}


	public Flight(int fid, @NotNull(message = "Name can't be null") String fname,
			@NotBlank(message = "Can't be blank") String forigin,
			@NotBlank(message = "Can't be blank") String fdestination,
			@NotBlank(message = "Can't be blank") String darrival, @NotNull(message = "Can't be blank") int ddepart,
			@Min(1) int fpriceeco, @Min(1) int fpricebus) {
		super();
		this.fid = fid;
		this.fname = fname;
		this.forigin = forigin;
		this.fdestination = fdestination;
		this.darrival = darrival;
		this.ddepart = ddepart;
		this.fpriceeco = fpriceeco;
		this.fpricebus = fpricebus;
	}

	public String getDarrival() {
		return darrival;
	}

	public void setDarrival(String darrival) {
		this.darrival = darrival;
	}

	public int getDdepart() {
		return ddepart;
	}

	public void setDdepart(int ddepart) {
		this.ddepart = ddepart;
	}

	public int getFpriceeco() {
		return fpriceeco;
	}

	public void setFpriceeco(int fpriceeco) {
		this.fpriceeco = fpriceeco;
	}

	public int getFpricebus() {
		return fpricebus;
	}

	public void setFpricebus(int fpricebus) {
		this.fpricebus = fpricebus;
	}



	public Flight() {
		super();
	}

	@Override
	public String toString() {
		return "Flight [fid=" + fid + ", fname=" + fname + ", forigin=" + forigin + ", fdestination=" + fdestination
				+ ", darrival=" + darrival + ", ddepart=" + ddepart + ", fpriceeco=" + fpriceeco + ", fpricebus="
				+ fpricebus + "]";
	}

}
